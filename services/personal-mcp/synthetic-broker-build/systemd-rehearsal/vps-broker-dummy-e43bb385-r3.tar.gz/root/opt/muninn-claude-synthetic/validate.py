#!/usr/bin/env python3
"""Inert unless explicitly approved, inside the dedicated dummy RootDirectory."""
import base64,ctypes,hashlib,json,os,pathlib,resource,select,signal,socket,sqlite3,subprocess,sys,tempfile,time
ROOT=pathlib.Path('/opt/muninn-claude-synthetic')
HELPER=ROOT/'broker-helper-linux-amd64'
EXPECTED='6cbbda167477d5e4365cf36b14e6d2b45c41baa0c6032004901318c509022989'
DB=pathlib.Path('/opt/philotic/data/aiua_context.db')
def prepare_database(db):
 conn=sqlite3.connect(db)
 try:conn.executescript('CREATE TABLE graph_nodes(node_key TEXT PRIMARY KEY,kind TEXT NOT NULL,label TEXT,data_json TEXT NOT NULL,updated_at DATETIME DEFAULT CURRENT_TIMESTAMP);CREATE TABLE graph_edges(edge_key TEXT PRIMARY KEY,src_node_key TEXT NOT NULL,edge_kind TEXT NOT NULL,dst_node_key TEXT NOT NULL,data_json TEXT NOT NULL,updated_at DATETIME DEFAULT CURRENT_TIMESTAMP);')
 finally:conn.close()
 # CAP_CHOWN permits transfer, but without CAP_FOWNER root may not chmod a
 # transferred inode. Finish mode changes while the supervisor still owns it.
 db.chmod(0o600)
 os.chown(db,999,987)
 os.chown(db.parent,999,987)
 st=db.stat();assert st.st_uid==999 and st.st_gid==987 and st.st_mode&0o777==0o600
 st=db.parent.stat();assert st.st_uid==999 and st.st_gid==987
CAP_NAMES='CHOWN DAC_OVERRIDE DAC_READ_SEARCH FOWNER FSETID KILL SETGID SETUID SETPCAP LINUX_IMMUTABLE NET_BIND_SERVICE NET_BROADCAST NET_ADMIN NET_RAW IPC_LOCK IPC_OWNER SYS_MODULE SYS_RAWIO SYS_CHROOT SYS_PTRACE SYS_PACCT SYS_ADMIN SYS_BOOT SYS_NICE SYS_RESOURCE SYS_TIME SYS_TTY_CONFIG MKNOD LEASE AUDIT_WRITE AUDIT_CONTROL SETFCAP MAC_OVERRIDE MAC_ADMIN SYSLOG WAKE_ALARM BLOCK_SUSPEND AUDIT_READ PERFMON BPF CHECKPOINT_RESTORE'.split()
def cap_names(mask):
 return ['CAP_'+(CAP_NAMES[i] if i<len(CAP_NAMES) else 'UNKNOWN_'+str(i)) for i in range(64) if mask&(1<<i)]
def check_supervisor_caps():
 status=dict(line.split(':',1) for line in pathlib.Path('/proc/self/status').read_text().splitlines() if ':' in line)
 expected=sum(1<<i for i in [0,1,5,6,7,21]) # CHOWN,DAC_OVERRIDE,KILL,SETGID,SETUID,SYS_ADMIN
 masks={}
 for key in ['CapEff','CapPrm','CapBnd','CapInh','CapAmb']:
  raw=status[key].strip()
  assert 1<=len(raw)<=16 and all(c in '0123456789abcdefABCDEF' for c in raw),'invalid capability mask'
  masks[key]=int(raw,16)
 print(json.dumps({'phase':'supervisor-capabilities','expected_mask':hex(expected),'expected_names':cap_names(expected),
  'sets':{key:{'mask':hex(mask),'names':cap_names(mask)} for key,mask in masks.items()},
  'no_new_privileges':status['NoNewPrivs'].strip()=='1'}),flush=True)
 for key in ['CapEff','CapPrm','CapBnd']:assert masks[key]==expected,(key,'unexpected capability set')
 for key in ['CapInh','CapAmb']:assert masks[key]==0,(key,'unexpected capability set')
 assert status['NoNewPrivs'].strip()=='1'
 return hex(expected)
ATTACK=r'''
import ctypes,json,os,sys
v=json.loads(sys.stdin.readline());pid=v['pid'];out={}
for label,path in [('root',f'/proc/{pid}/root/run'),('fd',f"/proc/{pid}/fd/{v['fd']}"),('mem',f'/proc/{pid}/mem')]:
 try:
  if label=='fd':os.readlink(path)
  else:
   fd=os.open(path,os.O_RDONLY)
   if label=='mem' and 'address' in v:assert os.pread(fd,6,v['address'])==b'PUBLIC'
   os.close(fd)
  out[label]={'allowed':True,'errno':0}
 except OSError as e:out[label]={'allowed':False,'errno':e.errno}
libc=ctypes.CDLL(None,use_errno=True);ok=libc.ptrace(16,pid,0,0)==0
out['ptrace']={'allowed':ok,'errno':0 if ok else ctypes.get_errno()}
if ok:os.waitpid(pid,0);libc.ptrace(17,pid,0,0)
print(json.dumps(out))
'''
CONTROL=r'''
import ctypes,json,os,sys,time
libc=ctypes.CDLL(None);assert libc.prctl(0x59616d61,int(sys.argv[1]),0,0,0)==0
b=ctypes.create_string_buffer(b'PUBLIC');f=open('/dev/null')
print(json.dumps({'pid':os.getpid(),'fd':f.fileno(),'address':ctypes.addressof(b)}),flush=True)
time.sleep(30)
'''
def drop():os.setgroups([]);os.setgid(987);os.setuid(999)
def ready(p):
 assert select.select([p.stdout],[],[],3)[0],'readiness timeout'
 return json.loads(p.stdout.readline())
def attacker():return subprocess.Popen(['/usr/bin/python3','-c',ATTACK],preexec_fn=drop,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def attack(p,metadata):
 out,err=p.communicate(json.dumps(metadata).encode(),timeout=3)
 assert p.returncode==0,'adversary infrastructure failure'
 return json.loads(out)
def deny(result):assert all(not x['allowed'] and x['errno'] in (1,13) for x in result.values()),'missing permission denial'
def request():return json.dumps({'operation':'create','kind':'percival-muninn-observe','secret':'PUBLIC_DUMMY_VALUE_ONLY_0123456789abcdef'}).encode()
def check_mount_layout():
 # Actual kernel mount flags, not os.access(), which is misleading for root.
 expected={'/':True,'/usr':True,'/proc':True,'/opt/philotic':True,'/opt/philotic/data':False,'/run':False,'/results':False}
 observed={p:bool(os.statvfs(p).f_flag & os.ST_RDONLY) for p in expected}
 print(json.dumps({'mount_readonly':observed}),flush=True)
 assert observed==expected,'mount writability differs from reviewed chroot layout'
 return observed
def main():
 if sys.argv[1:]!=['--approved-vps-dummy']:
  print('{"plan":true,"live_changes":false}');return
 assert os.geteuid()==0 and sys.platform=='linux'
 assert os.getpid()==1 and pathlib.Path('/proc/self/stat').read_text().split()[0]=='1','private PID namespace and matching proc view required'
 assert any(p.split()[1]=='/proc' and 'ro' in p.split()[3].split(',') for p in pathlib.Path('/proc/mounts').read_text().splitlines()),'read-only private proc required'
 assert pathlib.Path('/DUMMY_ONLY').read_text()=='broker-e43bb385-public-fixture-only\n'
 assert not DB.exists() and not list(DB.parent.iterdir()),'fresh dummy database directory required'
 assert hashlib.sha256(HELPER.read_bytes()).hexdigest()==EXPECTED
 assert pathlib.Path('/proc/sys/fs/suid_dumpable').read_text().strip()=='2'
 assert pathlib.Path('/proc/sys/kernel/yama/ptrace_scope').read_text().strip()=='1'
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
 capabilities=check_supervisor_caps()
 mount_layout=check_mount_layout()
 prepare_database(DB)
 print(json.dumps({'database_ownership_mode_setup':True,'supervisor_capabilities':capabilities}),flush=True)
 # Regression: real SQLite writes/journaling after the exact UID/GID drop, at
 # the production helper's fixed absolute path inside the isolated root.
 probe=subprocess.run(['/usr/bin/python3','-c',"import sqlite3; c=sqlite3.connect('file:/opt/philotic/data/aiua_context.db?mode=rw',uri=True); c.execute(\"INSERT INTO graph_nodes(node_key,kind,data_json) VALUES('layout-probe','dummy','{}')\"); c.rollback(); assert c.execute('SELECT count(*) FROM graph_nodes').fetchone()[0]==0; c.close()"],preexec_fn=drop,capture_output=True,timeout=5,env={'PATH':'/usr/bin:/bin'})
 if probe.returncode:print(json.dumps({'uid999_sqlite_error':probe.stderr.decode(errors='replace')[:1500]}),flush=True)
 assert probe.returncode==0,'UID999 SQLite reopen/write/rollback regression failed'
 print(json.dumps({'uid999_sqlite_regression':True}),flush=True)
 report={'public_dummy_only':True,'artifact_sha256':EXPECTED,'kernel':os.uname().release,'suid_dumpable':2,'yama_scope':1,'production_data_access':False,'mount_readonly':mount_layout,'uid999_sqlite_regression':True,'supervisor_capabilities':capabilities}
 # A designated tracer exception applies only to this new public dummy target.
 a=attacker();control=None
 try:
  control=subprocess.Popen(['/usr/bin/python3','-c',CONTROL,str(a.pid)],preexec_fn=drop,stdout=subprocess.PIPE)
  report['positive_controls']=attack(a,ready(control))
  print(json.dumps({'positive_controls':report['positive_controls']}),flush=True)
  assert all(x['allowed'] for x in report['positive_controls'].values()),'positive controls unavailable'
 finally:
  if a.poll() is None:a.kill();a.wait()
  if control is not None:control.kill();control.wait()
 # Exercise exact released helper held after protected READY, before dummy delivery.
 home=tempfile.mkdtemp(prefix='synthetic-key-',dir='/run');parent,peer=socket.socketpair();child=None;a=None
 try:
  child=subprocess.Popen(['/usr/bin/unshare','--mount','--propagation','private','/usr/bin/python3',str(ROOT/'private_key_handoff.py'),'--approved-private-handoff','--child',home,'--channel-fd',str(peer.fileno())],pass_fds=(peer.fileno(),),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={'PATH':'/usr/bin:/bin'})
  child_fd=peer.fileno();peer.close();parent.settimeout(5)
  message=b''
  while len(message)<6:
   part=parent.recv(6-len(message));assert part,'readiness EOF';message+=part
  assert message==b'READY\n'
  os.kill(child.pid,signal.SIGSTOP)
  def stopped():return any(s.startswith('State:') and s.split()[1]=='T' for s in pathlib.Path(f'/proc/{child.pid}/status').read_text().splitlines())
  end=time.monotonic()+1
  while not stopped() and time.monotonic()<end:time.sleep(.01)
  assert stopped()
  a=attacker();report['protected_denials']=attack(a,{'pid':child.pid,'fd':child_fd});deny(report['protected_denials']);assert stopped()
  print(json.dumps({'protected_denials':report['protected_denials']}),flush=True)
  assert list(pathlib.Path(home).iterdir())==[],'host namespace key exposure'
  parent.sendall(b'PHILOTIC_VAULT_MASTER_KEY='+base64.b64encode(bytes([7])*32)+b'\n');parent.shutdown(socket.SHUT_WR)
  child.stdin.write(request());child.stdin.close();child.stdin=None;os.kill(child.pid,signal.SIGCONT)
  out,err=child.communicate(timeout=10);assert child.returncode==0,'dummy create/readback failed'
  ref=json.loads(out)['reference']
 finally:
  if a is not None and a.poll() is None:a.kill();a.wait()
  if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
  parent.close();peer.close();os.rmdir(home)
 # Delete only the returned reference from this fresh, isolated dummy database.
 deleted=subprocess.run([str(HELPER),'--apply-scoped-synthetic'],input=json.dumps({'operation':'delete','kind':'percival-muninn-observe','reference':ref}).encode(),preexec_fn=drop,capture_output=True,timeout=5,env={'PATH':'/usr/bin:/bin'})
 assert deleted.returncode==0 and json.loads(deleted.stdout)=={'deleted':True}
 conn=sqlite3.connect(DB);assert conn.execute('SELECT count(*) FROM graph_nodes').fetchone()[0]==0;conn.close()
 assert not list(pathlib.Path('/run').glob('synthetic-key-*'))
 assert pathlib.Path('/proc/sys/fs/suid_dumpable').read_text().strip()=='2'
 report.update(dummy_create_readback_delete=True,private_mount_cleanup=True,sysctl_unchanged=True,transition_window_retested=False,production_activation=False)
 pathlib.Path('/results/receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'dummy_validation_passed':True}))
if __name__=='__main__':main()
