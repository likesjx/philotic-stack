#!/bin/sh
set -eu
# This shell must be PID 1 in the fresh namespace created by the runtime unit.
[ "$$" -eq 1 ]
# The replacement proc mount must not expose writable global kernel settings.
/usr/bin/mount -o remount,ro,nosuid,nodev,noexec /proc
exec /usr/bin/python3 /opt/muninn-claude-synthetic/validate.py --approved-vps-dummy
